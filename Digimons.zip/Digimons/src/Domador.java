
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 * Clase Domador
 */
public class Domador {
    /**
     * Atributos de la clase
     */
    private String nombre;
    private final ArrayList<Digimon> equipo;

    /**
     * Constructor de Domador
     * @param nombre 
     */
    public Domador(String nombre) {
        this.setNombre(nombre);
        this.equipo = new ArrayList<>();
        this.equipo.add(crearDigimonAleatorio());
    }

    /**
     * Método para crear un Digimon Aleatorio
     */
    private Digimon crearDigimonAleatorio() {
        String[] nombres = {"Agumon", "Gabumon", "Patamon"};
        Random rand = new Random();
        String nombre = nombres[rand.nextInt(nombres.length)];
        return new Digimon(nombre);
    }

    /**
     * Método para capturar un Digimon
     * @param digimon
     */
    public void captura(Digimon digimon) {
        if (digimon.getSalud() <= 20) {
            if (equipo.size() < 3) {
                equipo.add(digimon);
                System.out.println(digimon.getNombre() + " se ha unido a su equipo.");
            } else {
                System.out.println("El equipo ya está lleno.");
            }
        } else {
            System.out.println("No se puede unir.");
        }
    }

    public ArrayList<Digimon> getEquipo() {
        return equipo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}

