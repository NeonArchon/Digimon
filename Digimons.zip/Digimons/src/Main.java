
import java.util.InputMismatchException;
import java.util.Scanner;

        /**
         * clase principal
        * @param args
         */

	// Clase Main básica
	public class Main {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        try {
	            System.out.print("Ingrese el nombre del domador: ");
	            String nombre = scanner.nextLine();
	            Domador domador = new Domador(nombre);
	            BatallaDigital batalla = new BatallaDigital();

	            while (true) {
	                System.out.println("1. Iniciar batalla");
	                System.out.println("2. Salir");
	                System.out.print("Elige una opción: ");
	                try {
	                    int opcion = scanner.nextInt();
	                    if (opcion == 1) {
	                        Digimon digimon = batalla.elige(domador, scanner);
	                        batalla.pelea(digimon, domador, scanner);
	                    } else if (opcion == 2) {
	                        break;
	                    } else {
	                        System.out.println("Opción no válida. Por favor, elige 1 o 2.");
	                    }
	                } catch (InputMismatchException e) {
	                    System.out.println("Entrada no válida. Por favor, introduce un número.");
	                    scanner.next();  // Limpiar la entrada no válida
	                }
	            }
	        } finally {
	            scanner.close();
	        }
	    }
	}