import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.NoSuchElementException;
import java.util.Random;
import java.util.Scanner;

public class BatallaDigital {

    private final Digimon enemigo;

    public BatallaDigital() {
        this.enemigo = crearDigimonAleatorio();
    }

    /**
     * Método para crear un Digimon Aleatorio
     * @return
     */
    private Digimon crearDigimonAleatorio() {
        String[] nombres = {"Agumon", "Gabumon", "Patamon"};
        Random rand = new Random();
        String nombre = nombres[rand.nextInt(nombres.length)];
        return new Digimon(nombre);
    }

    /**
     * Método para elegir un Digimon
     * @param domador
     * @return
     */
    public Digimon elige(Domador domador, Scanner scanner) {
        ArrayList<Digimon> equipo = domador.getEquipo();
        while (true) {
            for (int i = 0; i < equipo.size(); i++) {
                Digimon digimon = equipo.get(i);
                System.out.println((i + 1) + ". " + digimon.getNombre() + " (Salud: " + digimon.getSalud() + ")");
            }
            System.out.print("Elige el Digimon para la batalla: ");
            try {
                int eleccion = scanner.nextInt() - 1;
                if (eleccion >= 0 && eleccion < equipo.size()) {
                    return equipo.get(eleccion);
                } else {
                    System.out.println("Selección inválida. Por favor, elige un número válido.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada no válida. Por favor, introduce un número.");
                scanner.next();  // Limpiar la entrada no válida
            }
        }
    }

    /**
     * Método de Pelea
     * @param digimon
     * @param domador
     */
    public void pelea(Digimon digimon, Domador domador, Scanner scanner) {
        if (digimon == null) {
            System.out.println("No se seleccionó un Digimon válido para la pelea.");
            return;
        }

        while (enemigo.getSalud() > 0 && digimon.getSalud() > 0) {
            System.out.println("\n" + digimon.getNombre() + " (Salud: " + digimon.getSalud() + ") vs " + enemigo.getNombre() + " (Salud: " + enemigo.getSalud() + ")");
            System.out.print("Elige tu acción: 1. Ataque1, 2. Ataque2, 3. Capturar: ");
            try {
                int accion = scanner.nextInt();
                switch (accion) {
                    case 1 -> digimon.ataque1(enemigo);
                    case 2 -> digimon.ataque2(enemigo);
                    case 3 -> {
                        domador.captura(enemigo);
                        if (domador.getEquipo().contains(enemigo)) {
                            break;
                        }
                    }
                    default -> System.out.println("Acción no válida. Por favor, elige 1, 2 o 3.");
                }
                if (enemigo.getSalud() > 0) {
                    enemigo.ataque1(digimon);
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada no válida. Por favor, introduce un número.");
                scanner.next();  // Limpiar la entrada no válida
            } catch (NoSuchElementException e) {
                System.out.println("No se encontró la entrada esperada. Asegúrese de proporcionar un número entero.");
                break;
            }
        }

        if (digimon.getSalud() <= 0) {
            System.out.println(digimon.getNombre() + " ha sido derrotado.");
        } else if (enemigo.getSalud() <= 0) {
            System.out.println(enemigo.getNombre() + " ha sido derrotado.");
        }
    }
}
