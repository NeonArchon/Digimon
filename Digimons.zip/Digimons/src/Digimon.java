
import java.util.Random;
/**
* clase Digimon
*/
public class Digimon {
    

	/**
	 *atributos de la clase Digimon
	 */
   
   private final String nombre;
   private final int nivel;
   private final int puntosAtaque;
   private int salud;
   private int dp1;
   private int dp2;
   
	/**
	 *constructor de la clase Digimon
     * @param nombre
	 */

   public Digimon(String nombre) {
       this.nombre = nombre;
       Random rand = new Random();
       this.nivel = rand.nextInt(5) + 1;
       this.puntosAtaque = 5 * this.nivel;
       this.salud = 10 * this.nivel;
       this.dp1 = 10;
       this.dp2 = 10;
   }

	/**
	 *getters y setters de la clase Digimon
     * @return 
	 */

   public String getNombre() {
       return nombre;
   }

   public int getSalud() {
       return salud;
   }
   
	/**
	 *Metodo del atquede debil (Ataque1)
     * @param objetivo
	 */

   public void ataque1(Digimon objetivo) {
       if (dp1 > 0) {
           dp1--;
           objetivo.salud -= this.puntosAtaque;
           System.out.println(this.nombre + " usa Ataque1 en " + objetivo.nombre + " causando " + this.puntosAtaque + " de daño.");
       } else {
           System.out.println(this.nombre + " no tiene suficiente DP para Ataque1.");
       }
   }
   
	/**
	 *Metodo del atquede fuerte (Ataque2)
     * @param objetivo
	 */

   public void ataque2(Digimon objetivo) {
       if (dp2 > 1) {
           dp2 -= 2;
           objetivo.salud -= 2 * this.puntosAtaque;
           System.out.println(this.nombre + " usa Ataque2 en " + objetivo.nombre + " causando " + (2 * this.puntosAtaque) + " de daño.");
       } else {
           System.out.println(this.nombre + " no tiene suficiente DP para Ataque2.");
       }
   }
}

